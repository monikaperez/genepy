library(testthat)
library(taigr)

test_check("taigr")
